define(function() {

	return {
		constructor: function(baseConfig, layoutConfig, pspConfig) {

		},
		//Logic for getters/setters of custom properties
		initGettersSetters: function() {
            defineGetter(this, 'identityServiceName', () => {
                return this._identityServiceName;
            });
            defineSetter(this, 'identityServiceName', value => {
                this._identityServiceName = value;
            });
        },
      
      /**
      * This method is responsible to 
      * return the state of the rememberMe checkboc
      **/
      isRememberMeChecked: function() {
        kony.print("Entering into com.edification.login component's isRememberMeChecked");
        kony.print("State of the rememberMe checkbox: "+JSON.stringify(this.view.chbxRememberMe.selectedKeys));
        kony.print("Exiting out of com.edification.login component's isRememberMeChecked");
        if("rememberMe" === this.view.chbxRememberMe.selectedKeys[0]) {
          return true;
        } else {
         return false; 
        }
      },
      
      /**
      * This function is responsible to handle the login success.
      * From this function the actions configured by the consumer of this component, 
      * using the custom event loginSuccessCallback, of this component exposes, those will be executed
      **/
      _loginSuccessCallback: function() {
        kony.print("Entering into com.edification.login component's _loginSuccessCallback");
        this.loginSuccessCallback();
        kony.print("Exiting out of com.edification.login component's _loginSuccessCallback");
      },

      /**
      * This function is responsible to handle the login error.
      * From this function the actions configured by the consumer of this component, 
      * using the custom event loginFailureCallback, of this component exposes, those will be executed
      **/
      _loginFailureCallback: function() {
        kony.print("Entering into com.edification.login component's _loginFailureCallback");
        this.loginFailureCallback();
        kony.print("Exiting out of com.edification.login component's _loginFailureCallback");
      },
      
      /**
      * This function is responsible to invoke the identity service call,
      * using the value provided in the identityServiceName custom property
      **/
      login: function() {
        var identityService = kony.sdk.getCurrentInstance().getIdentityService(this._identityServiceName);
        
        var options = {};
        options["userid"]=this.view.tbxUsername.text;
        options["password"]=this.view.tbxPassword.text;
        
        identityService.login(options, this._loginSuccessCallback.bind(this), this._loginFailureCallback.bind(this));
      }
	};
});