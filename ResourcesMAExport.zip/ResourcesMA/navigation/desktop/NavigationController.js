define({
    //Add your navigation controller code here.
});